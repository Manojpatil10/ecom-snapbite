import { useState } from "react"
import { Link } from "react-router-dom"

function ForgotPasswordPage() {

  const [email, setEmail] = useState("")

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault()

    const res = await fetch("http://localhost:8080/api/auth/forgot-password", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email })
    })

    const data = await res.json()

    if (res.ok) {
      alert("Password reset link sent to email")
    } else {
      alert(data.message || "Error sending reset link")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">

      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">

        <h1 className="text-2xl font-bold mb-6 text-center">
          Reset Password
        </h1>

        <form onSubmit={handleForgotPassword} className="space-y-4">

          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border p-2 rounded"
            required
          />

          <button
            type="submit"
            className="w-full bg-black text-white py-2 rounded hover:bg-gray-800"
          >
            Send Reset Link
          </button>

        </form>

        <p className="text-center text-sm mt-4">
          <Link to="/login" className="text-blue-500">
            Back to Login
          </Link>
        </p>

      </div>

    </div>
  )
}

export default ForgotPasswordPage