function Footer() {
  return (
    <footer className="mt-20 bg-gray-100 py-6 text-center text-gray-600">

      <p>
        © 2026 Ecommerce Store
      </p>

    </footer>
  )
}

export default Footer