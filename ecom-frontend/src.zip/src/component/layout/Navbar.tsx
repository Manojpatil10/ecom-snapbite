import { Link } from "react-router-dom"

function Navbar() {
  return (
    <nav className="bg-gray-900 text-white px-6 py-4 flex items-center justify-between">

      <h1 className="text-xl font-semibold">
        Ecommerce
      </h1>

      <div className="flex gap-6">

        <Link
          to="/"
          className="hover:text-gray-300 transition"
        >
          Home
        </Link>

        <Link
          to="/cart"
          className="hover:text-gray-300 transition"
        >
          Cart
        </Link>

        <Link
          to="/login"
          className="hover:text-gray-300 transition"
        >
          Login
        </Link>

      </div>

    </nav>
  )
}

export default Navbar