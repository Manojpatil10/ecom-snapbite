import { Link } from "react-router-dom"

type Props = {
  id: number
  name: string
  price: number
  imageUrl?: string
}

function ProductCard({ id, name, price, imageUrl }: Props) {

  return (
    <div className="border rounded-lg p-4 hover:shadow-lg transition">

      <Link to={`/products/${id}`}>

        <img
          src={imageUrl || "https://via.placeholder.com/200"}
          alt={name}
          className="w-full h-40 object-cover mb-4 rounded"
        />

        <h3 className="text-lg font-semibold">
          {name}
        </h3>

      </Link>

      <p className="text-gray-600 mt-2">
        ₹{price}
      </p>

      <button
        className="mt-4 w-full bg-black text-white py-2 rounded hover:bg-gray-800 transition"
      >
        Add to Cart
      </button>

    </div>
  )
}

export default ProductCard