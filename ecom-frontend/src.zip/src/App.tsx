import './App.css'
import Footer from './component/layout/Footer'
import Navbar from './component/layout/Navbar'
import AppRoutes from './routes/AppRoutes'

function App() {

  return (
    <>
      <Navbar />
      <AppRoutes />
      <Footer />
    </>
  )
}

export default App
