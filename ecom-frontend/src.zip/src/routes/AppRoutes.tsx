import { Routes, Route } from "react-router-dom"
import HomePage from "../pages/HomePage"
import ProductPage from "../pages/ProductPage"
import CartPage from "../pages/CartPage"
import LoginPage from "../component/auth/LoginPage"
import RegisterPage from "../component/auth/RegisterPage"
import ForgotPasswordPage from "../component/auth/ForgetPasswordPage"

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/products/:id" element={<ProductPage />} />
      <Route path="/cart" element={<CartPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
    </Routes>
  )
}

export default AppRoutes