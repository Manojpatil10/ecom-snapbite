function CartPage() {

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">

      <h1 className="text-3xl font-bold mb-6">
        Your Cart
      </h1>

      <div className="border rounded-lg p-6 bg-white shadow">

        <p className="text-gray-500">
          No items added yet.
        </p>

      </div>

    </div>
  )
}

export default CartPage