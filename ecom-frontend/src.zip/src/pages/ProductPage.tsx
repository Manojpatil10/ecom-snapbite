import { useParams } from "react-router-dom"
import { useEffect, useState } from "react"

type Product = {
  id: number
  name: string
  description: string
  price: number
  imageUrl?: string
}

function ProductPage() {

  const { id } = useParams()
  const [product, setProduct] = useState<Product | null>(null)

  useEffect(() => {

    fetch(`http://localhost:8080/api/products/${id}`)
      .then(res => res.json())
      .then(data => setProduct(data))
      .catch(err => console.error(err))

  }, [id])

  if (!product) {
    return (
      <div className="flex justify-center items-center h-screen">
        <h2 className="text-xl">Loading product...</h2>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">

      <div className="grid md:grid-cols-2 gap-10">

        {/* Product Image */}
        <div>
          <img
            src={product.imageUrl || "https://via.placeholder.com/400"}
            alt={product.name}
            className="w-full rounded-lg shadow"
          />
        </div>

        {/* Product Info */}
        <div className="space-y-6">

          <h1 className="text-3xl font-bold">
            {product.name}
          </h1>

          <p className="text-gray-600">
            {product.description}
          </p>

          <h2 className="text-2xl font-semibold text-green-600">
            ₹{product.price}
          </h2>

          <button
            className="bg-black text-white px-6 py-3 rounded hover:bg-gray-800 transition"
          >
            Add to Cart
          </button>

        </div>

      </div>

    </div>
  )
}

export default ProductPage