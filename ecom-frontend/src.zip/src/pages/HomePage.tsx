import ProductCard from "../component/products/ProductCard"

function HomePage() {

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">

      <h1 className="text-3xl font-bold mb-8">
        Welcome to our Ecommerce Store
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">

        <ProductCard id={1} name="Laptop" price={80000} />

        <ProductCard id={2} name="Phone" price={30000} />

      </div>

    </div>
  )
}

export default HomePage